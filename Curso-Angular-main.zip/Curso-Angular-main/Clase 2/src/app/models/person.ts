export class Person {
  edad: number;
  nombre: string;
  apellido: string;

  constructor(edad: number, nombre: string, apellido: string) {
    this.edad = edad;
    this.nombre = nombre;
    this.apellido = apellido;
  }
}
