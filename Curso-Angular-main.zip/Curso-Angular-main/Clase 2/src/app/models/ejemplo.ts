export class Ejemplo {

}
