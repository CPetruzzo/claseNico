export const environment = {
  production: true,
  backUrl: 'http://tesis.lia.unrn.edu.ar:3000/'
};
